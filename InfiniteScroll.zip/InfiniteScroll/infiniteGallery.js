class InfiniteGallery {
  constructor(containerId, loaderId) {
    this.container = // Récupérer la classe image du HTML
    this.loader = // Récupérer la div avec le #loader
    this.isLoading = // Booléen initial de l'état du loading. Initialisé à false;
    this.page = // Page API, voir sur la documentation de l'api;
    this.limit = // Nombre d'images envoyé par l'api;
    // Appel de la fonction qui écoute l'évènement de scroll
    // Appel de la fonction pour récupérer les premières images
    }

  ecouteEvenement() {
    // Ajouter un écouteur d'évènement sur le scroll de la fenêtre
  }

  gererScroll() {
    

    // Calculer si la position actuelle [window.innerHeight + window.scrollY] > à la hauteur de la page [document.documentElement.scrollHeight] Ajouter une marge de quelques pixels. Dans ce cas, appeller la méthode pour charger d'autres images.
  }

  gererChargement(show) {
    

    // Changement d'état du loader. Passant de display none à block dépendemment de show qu'est un booléen.
  }

  async fetchImages() {
    

    // Gérer l'appel api
  }

  afficherImage(images) {
    
  }

  // Ajouter dans le HTML
}

let infinite = // Instance de la classe;
